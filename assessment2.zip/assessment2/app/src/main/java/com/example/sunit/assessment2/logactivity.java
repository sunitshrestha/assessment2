package com.example.sunit.assessment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import Data.DatabaseHandler;
import Model.Trips;

public class logactivity extends AppCompatActivity {

    private EditText title,type,comment,destination,duration,date;
    private Button save,cancel;

    private DatabaseHandler dba;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logactivity);


        title=(EditText)findViewById(R.id.editTitleText);
        date=(EditText)findViewById(R.id.editDateText2);
        type=(EditText)findViewById(R.id.editTriptypeText3);
        destination=(EditText)findViewById(R.id.editDestinationText4);
        duration=(EditText)findViewById(R.id.editDurationText5);
        comment=(EditText)findViewById(R.id.editCommentText6);
        save=(Button)findViewById(R.id.buttonsave);
        cancel=(Button)findViewById(R.id.buttoncancel);


        dba= new DatabaseHandler(logactivity.this);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addtrips();

            }

        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canceltrips();
            }
        });






    }

    private void canceltrips() {
        title.setText("");
        date.setText("");
        type.setText("");
        destination.setText("");
        duration.setText("");
        comment.setText("");

        Intent intent = new Intent(logactivity.this,MainActivity.class);
        startActivity(intent);
    }

    private void addtrips() {
        Trips trips = new Trips();

        trips.setTitle(title.getText().toString().trim());
        trips.setDate(date.getText().toString().trim());
        trips.setTripType(type.getText().toString().trim());
        trips.setDestination(destination.getText().toString().trim());
        trips.setDuration(duration.getText().toString().trim());
        trips.setComment(comment.getText().toString().trim());

        dba.addTrips(trips);
        dba.close();

        title.setText("");
        date.setText("");
        type.setText("");
        destination.setText("");
        duration.setText("");
        comment.setText("");

        Intent intent = new Intent(logactivity.this,MainActivity.class);
        startActivity(intent);
    }
    }





package com.example.sunit.assessment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import Data.DatabaseHandler;
import Model.Trips;


public class settingsactivity extends AppCompatActivity {

    private EditText name, id, email, gender, comment;
    private Button save;
    private DatabaseHandler dba;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settingsactivity);


        name=(EditText) findViewById(R.id.editNameText7);
        id=(EditText) findViewById(R.id.editIdText8);
        email=(EditText) findViewById(R.id.editEmailText9);
        gender=(EditText) findViewById(R.id.editGenderText10);
        comment=(EditText) findViewById(R.id.editCommentText11);
        save=(Button) findViewById(R.id.button5);
        dba= new DatabaseHandler(settingsactivity.this);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
    }
    private void save() {
        Trips trips = new Trips();

        trips.setTitle(name.getText().toString().trim());
        trips.setDate(id.getText().toString().trim());
        trips.setTripType(email.getText().toString().trim());
        trips.setDestination(gender.getText().toString().trim());
        trips.setComment(comment.getText().toString().trim());


        dba.addTrips(trips);
        dba.close();

        name.setText("");
        id.setText("");
        email.setText("");
        gender.setText("");
        comment.setText("");

        Intent intent = new Intent(settingsactivity.this,MainActivity.class);
        startActivity(intent);
    }
}


